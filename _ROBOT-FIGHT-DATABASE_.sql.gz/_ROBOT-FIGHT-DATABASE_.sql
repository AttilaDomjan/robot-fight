-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 21, 2024 at 11:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `robot-fight_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `robot`
--

CREATE TABLE `robot` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(20) NOT NULL,
  `type` enum('brawler','rogue','assault') NOT NULL,
  `power` int(10) UNSIGNED NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `deleted_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `robot`
--

INSERT INTO `robot` (`id`, `name`, `type`, `power`, `created_at`, `deleted_at`) VALUES
(1, 'Robot', 'brawler', 150, '2024-08-20 16:48:34', NULL),
(2, 'Robot', 'brawler', 10, '2024-08-20 16:49:10', NULL),
(3, 'Robot', 'brawler', 10, '2024-08-20 16:49:15', NULL),
(4, '', 'brawler', 1, '2024-08-20 17:19:34', NULL),
(5, '', 'brawler', 1, '2024-08-20 17:24:37', NULL),
(6, '', 'brawler', 1, '2024-08-20 17:27:47', NULL),
(7, '', 'brawler', 1, '2024-08-20 17:28:19', NULL),
(8, '', 'brawler', 1, '2024-08-20 17:29:42', NULL),
(9, '', 'brawler', 1, '2024-08-20 17:37:07', NULL),
(10, '', 'brawler', 1, '2024-08-20 17:38:08', NULL),
(11, '', 'brawler', 1, '2024-08-20 17:40:35', NULL),
(12, '', 'brawler', 1, '2024-08-20 17:42:10', NULL),
(13, '', 'brawler', 1, '2024-08-20 17:42:41', NULL),
(14, '', 'brawler', 1, '2024-08-20 17:42:59', NULL),
(15, '', 'brawler', 1, '2024-08-20 17:51:59', NULL),
(16, '', 'brawler', 43, '2024-08-20 18:23:24', NULL),
(17, '', 'brawler', 43, '2024-08-20 18:24:09', NULL),
(18, 'Terminator', 'brawler', 10, '2024-08-20 18:33:43', NULL),
(19, 'Terminator', 'brawler', 10, '2024-08-20 18:33:51', NULL),
(20, 'Terminator', 'brawler', 10, '2024-08-20 18:33:55', NULL),
(21, 'Terminator', 'assault', 10, '2024-08-20 18:34:48', NULL),
(22, 'Walley', 'rogue', 98, '2024-08-20 18:44:39', NULL),
(23, 'Bunnybot', 'assault', 76, '2024-08-20 18:49:05', NULL),
(24, 'Atom', 'brawler', 66, '2024-08-20 19:52:54', NULL),
(25, 'Poknuk', 'assault', 78, '2024-08-20 19:56:49', NULL),
(26, 'Aztec', 'assault', 6800, '2024-08-20 19:57:35', NULL),
(27, 'Kelly', 'rogue', 7, '2024-08-21 00:47:38', NULL),
(28, 'Mana', 'rogue', 22, '2024-08-21 01:04:51', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `robot`
--
ALTER TABLE `robot`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `robot`
--
ALTER TABLE `robot`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
